package com.cg.PageObjects;


import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MarketPlace {
	
WebDriver driver;
	
	@FindBy(xpath="//*[@id=\"magento-tap2\"]/div/div/div[1]/div/nav/div/div[1]/a/span[1]/img")
	WebElement imgClick; 

	@FindBy(xpath="//*[@id=\"menu-item-4554\"]/a")
	WebElement addClick1;

	@FindBy(xpath="//*[@id=\"magento-tap2\"]/section/div/div/div/div[2]/div/a/div[3]/p")
    WebElement viewBtn;
	
	@FindBy(xpath="//*[@id=\"add-ons-div\"]/ul/li[1]/div/div[2]/p/a")
	WebElement addbtn;
	
	@FindBy(xpath="//*[@id=\"navbar\"]/ul[2]/li[2]/a/i")
	WebElement cartBtn;
	
	public  MarketPlace(WebDriver driver)
		{
			this.driver=driver;
			PageFactory.initElements(driver, this);
		}
	
	public void addClick() throws InterruptedException 
	{	
		imgClick.click();
		addClick1.click();
	}
	
	public void viewClick()
	{
		viewBtn.click();
	}
	
	public void choice()
	{
		 addbtn.click();
	}
	
	public void addToCart()
	{
		WebElement msgShow=driver.findElement(By.className("woocommerce-message"));
		 String str=msgShow.getText();
		 String str1="�Amazon� has been added to your cart.";
		assertTrue(str.equals(str1));
	}
	
}
