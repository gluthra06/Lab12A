package com.cg.PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class FeatureUsingSearch {
	
WebDriver driver;
	
	@FindBy(xpath="//*[@id=\"magento-tap2\"]/div/div/div[1]/div/nav/div/div[1]/a/span[1]/img")
	WebElement imgClick; 

	@FindBy(linkText="Add Ons")
	WebElement addClick;
	
	@FindBy(xpath="//*[@id=\"magento-tap2\"]/section/div/div/div/div[1]/div/a/div[3]/p")
	WebElement featureAdd;
	
	@FindBy()
	WebElement SearchTextBox;
	
	@FindBy()
	WebElement SearchBtn;
	
	

}
