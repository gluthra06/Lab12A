package com.cg.PageObjects;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class DemoPage {
	
	
	WebDriver driver;
	
	@FindBy(linkText="Demo")
     WebElement demo;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"magento-tap2\"]/section[1]/div/div/div[2]/div[2]/div/div[1]/div[2]/p/a[2]")
	WebElement link;
	
	@FindBy(id="username")
	WebElement userName;
	
	@FindBy(id="login")
    WebElement pass;
	
	@FindBy(className="form-button")
	WebElement loginBtn;
	
	@FindBy(className="demo-notice")
	WebElement element;
	
	public DemoPage(WebDriver driver)
	{
         this.driver=driver;
         PageFactory.initElements(driver, this);
	}
	
	public void demoClick()
	{
		demo.click();
	}	
	
	public void linkClick()
	{
		link.click();
		
	}
	
	public void enterUsername()
	{
		 userName.clear();
		 userName.sendKeys("adminusername");
	}
	
	public void enterPassword()
	{
		pass.clear();
		pass.sendKeys("adminpassword");
	}
	
	public void loginClick()
	{
		loginBtn.click();
	}
	
	public void newPage()
	{
		String str=element.getText();
		String str1="This is a demo store. Any orders placed through this store will not be honored or fulfilled.";
		assertEquals(str,str1);
	}
}
