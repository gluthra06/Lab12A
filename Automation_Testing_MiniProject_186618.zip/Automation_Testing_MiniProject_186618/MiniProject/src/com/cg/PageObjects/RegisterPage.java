package com.cg.PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegisterPage {
	
	WebDriver driver;
	@FindBy(xpath="//*[@id=\"header_lets_get_started_for_free\"]")
	WebElement startBtn;
	
	@FindBy(name="first_name")
	WebElement nameText;
	
	@FindBy(name="email")
	WebElement email;
	
	@FindBy(name="password")
	WebElement pass;
	
	@FindBy(name="get_started")
	WebElement btn;
	
	public RegisterPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}
	
	public void startClick()
	{
		startBtn.click();
	}

	
	public void userDetails()
	{
		nameText.clear();
		nameText.sendKeys("Gautam Luthra");
		
		email.clear();
		email.sendKeys("gluthra06@gmail.com");
		
		pass.clear();
		pass.sendKeys("Password1234");
	}
	
	public void register()
	{
		btn.click();
	}
}
