package com.cg.PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class DemoPage2 {
	
	WebDriver driver;
	
	@FindBy(linkText="Demo")
	WebElement demo;
	
	@FindBy(how=How.XPATH, using="//*[@id=\"magento-tap2\"]/section[1]/div/div/div[2]/div[2]/div/div[2]/div[2]/p/a[2]")
	WebElement link;
	
	@FindBy(id="username")
	WebElement userName;
	
	@FindBy(id="login")
    WebElement pass;
	
	@FindBy(linkText="Sign in")
	WebElement signBtn;
	
	public DemoPage2(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void demo()
	{
		 demo.click();
	}
	
	public void link()
	{
		link.click();
	}
    
	public void user()
	{
		userName.clear();
		userName.sendKeys("admin");
		pass.clear();
		pass.sendKeys("master2016");
	}
	
	public void click()
	{
		 signBtn.click();
	}
}
