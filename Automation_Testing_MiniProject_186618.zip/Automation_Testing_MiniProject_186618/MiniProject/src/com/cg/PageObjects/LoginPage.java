package com.cg.PageObjects;

import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	
	FileInputStream inputStream=null;

	WebDriver driver;
	@FindBy(linkText="Log in")
	WebElement login;
	
	@FindBy(id="login-username")
	WebElement userName;
	
	@FindBy(id="login-password")
	WebElement pass;
	
	@FindBy(name="login")
	WebElement btn;
	
	/*@FindBy(xpath="//*[@id=\"magento-tap2\"]/div/div/div[1]/div/nav/div/div[3]/ul/li[5]/a/div/span")
	WebElement roundClick;*/
	
	public LoginPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void readLoginData() throws FileNotFoundException, DocumentException
	{
		login.click();
		
		String filename=System.getProperty("user.dir")+"/src/com/cg/files/ReadData.xml";
		inputStream=new FileInputStream(new File(filename));
	    SAXReader reader= new SAXReader();   
	    Document doc=reader.read(inputStream);
	    String username=doc.selectSingleNode("//Read/Username").getText();
	    userName.sendKeys(username);
	    String password=doc.selectSingleNode("//Read/Password").getText();
		pass.sendKeys(password);
		btn.click();
	}
	
	public void LoggedIn()
	{
		try {
                    WebElement roundClick=driver.findElement(By.xpath("//*[@id=\"magento-tap2\"]/div/div/div[1]/div/nav/div/div[3]/ul/li[5]/a/div/span"));			
			}
		catch(Exception e)
		
		{
				assertTrue(false);
		}
	}
	
	public static void main(String[] args) throws FileNotFoundException, DocumentException {
		System.setProperty("webdriver-chromedriver", "D:\\chromedriver_win32 (1)\\chromedriver.exe");
		  WebDriver driver=new ChromeDriver();
		  driver.get("https://www.magentomobileshop.com/login/");
		  LoginPage lgPage=new LoginPage(driver);
		  lgPage.readLoginData();
		  lgPage.LoggedIn();
	}
}
