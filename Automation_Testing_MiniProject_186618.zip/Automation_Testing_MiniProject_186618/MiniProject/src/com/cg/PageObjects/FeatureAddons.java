package com.cg.PageObjects;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FeatureAddons 
{
	
	WebDriver driver;
	
	@FindBy(xpath="//*[@id=\"magento-tap2\"]/div/div/div[1]/div/nav/div/div[1]/a/span[1]/img")
	WebElement imgClick; 

	@FindBy(linkText="Add Ons")
	WebElement addClick;
	
	@FindBy(xpath="//*[@id=\"magento-tap2\"]/section/div/div/div/div[1]/div/a/div[3]/p")
	WebElement featureAdd;
	
	@FindBy(xpath="//*[@id=\"add-ons-div\"]/ul/li[1]/div/div[2]/p/a")
	WebElement choice;
	
	@FindBy(className="fa-shopping-cart")
	WebElement cart;
	
	@FindBy(xpath="//*[@id=\"post-358\"]/div/div/div[4]/div/div/div/a")
    WebElement ProceedBtn;
	
	public FeatureAddons(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void toFind() throws InterruptedException
	{
		imgClick.click();
		
		addClick.click();
		
		featureAdd.click();
		
		choice.click();	
	}
	
  public void addedToCart()
	{
		 WebElement msgShow=driver.findElement(By.className("woocommerce-message"));
		 String str=msgShow.getText();
		 String str1="�Abandoned Cart Notifications� has been added to your cart.";
		assertTrue(str.equals(str1));
		}
	   
     public void cartClick()
     {
    	 cart.click();
     }
     
     public void Proceed()
     {
    	 ProceedBtn.click();
     }
}	