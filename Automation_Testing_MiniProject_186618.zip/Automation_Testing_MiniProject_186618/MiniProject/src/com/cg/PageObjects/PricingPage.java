package com.cg.PageObjects;

public class PricingPage {
	
	

}
