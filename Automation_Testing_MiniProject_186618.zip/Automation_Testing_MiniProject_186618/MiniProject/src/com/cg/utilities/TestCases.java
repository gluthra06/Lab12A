package com.cg.utilities;

import static org.testng.Assert.assertFalse;

import java.io.FileNotFoundException;

import org.dom4j.DocumentException;
import org.junit.After;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.cg.PageObjects.DemoPage;
import com.cg.PageObjects.DemoPage2;
import com.cg.PageObjects.FeatureAddons;
import com.cg.PageObjects.LoginPage;
import com.cg.PageObjects.MarketPlace;
import com.cg.PageObjects.RegisterPage;

public class TestCases {
	WebDriver driver;
	LoginPage lPage;
	
	@BeforeMethod
	public void setup()
	{
		  System.setProperty("webdriver-chromedriver", "D:\\JavaPrgs\\MiniProject\\src\\com\\cg\\drivers\\chromedriver.exe");
		  driver=new ChromeDriver();
		  driver.get("https://www.magentomobileshop.com/");
	}
	
	public void changeTo(String title)
	{
		String getHandle=driver.getWindowHandle();
		for(String strHandle : driver.getWindowHandles())
		{
			driver.switchTo().window(strHandle);
			if(driver.getTitle().equals(title))
				break;
		}
	}
	/*List<WebElement> list = driver.findElements(By.cssSelector(li.item));
	 * list.size();
	 * 
	 * 
	 * */
	@Test
	public void TestCase1() throws FileNotFoundException, DocumentException
	{
		lPage=new LoginPage(driver);
		lPage.readLoginData();
	}
	
	/*@Test
	public void TestCase2() throws InterruptedException, FileNotFoundException, DocumentException
	{
		TestCase1();
	   FeatureAddons fadd=new FeatureAddons(driver);
	   fadd.toFind();
	   fadd.addedToCart();
	   fadd.cartClick();
	   
	   JavascriptExecutor js=(JavascriptExecutor) driver;
	   Thread.sleep(2000);
	   js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
	   fadd.Proceed();
	}*/
	
	@Test
	public void TestCase3() throws InterruptedException, FileNotFoundException, DocumentException
	{
		TestCase1();
		
		DemoPage demoPage=new DemoPage(driver);
		demoPage.demoClick();
		
		 JavascriptExecutor js=(JavascriptExecutor) driver;
		 Thread.sleep(2000);
		 js.executeScript("window.scrollBy(0,200)");
		demoPage.linkClick();
		
		changeTo("Log into Magneto Admin Page");
		Thread.sleep(2000);
		demoPage.enterUsername();
		demoPage.enterPassword();
		demoPage.loginClick();
		demoPage.newPage();
		
	}
	/*@Test
	public void TestCase4() throws FileNotFoundException, DocumentException, InterruptedException
	{
		String str="Magneto Admin";
		TestCase1();
		Thread.sleep(2000);
		DemoPage2 demo1=new DemoPage2(driver);
		demo1.demo();
		
		JavascriptExecutor js=(JavascriptExecutor) driver;
		 Thread.sleep(2000);
		 js.executeScript("window.scrollBy(0,300)");
		demo1.link();
		changeTo("Magento Admin");
		demo1.user();
		demo1.click();
		
		
	}*/
	
	
	/*@Test
	public void TestCases5() throws InterruptedException, FileNotFoundException, DocumentException 
	{
		TestCase1();
		MarketPlace mrktPlace=new MarketPlace(driver);
		mrktPlace.addClick();
		mrktPlace.viewClick();
		mrktPlace.choice();
		mrktPlace.addToCart();
	}*/

	
	/*@Test
	public void TestCases6()
	{
		RegisterPage register=new RegisterPage(driver);
		register.startClick();
		register.userDetails();
		register.register();
	}*/
	
	/*@After
	public void tearDown()
	{
		driver.close();
	}*/
}
