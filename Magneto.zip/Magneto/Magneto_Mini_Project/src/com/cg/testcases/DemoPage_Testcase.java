package com.cg.testcases;

import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.cg.pageobject.Demo_PageObject;

import com.cg.utilities.ExcelReader;

public class DemoPage_Testcase {
	

	WebDriver driver;
	Demo_PageObject demopg;

	

	@BeforeMethod
	public void startup() {
		System.setProperty("webdriver.chrome.driver","H:\\Mini_Project\\selenium-master\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.magentomobileshop.com");
		driver.manage().window().maximize();
		demopg = new Demo_PageObject(driver);
	
		
	}

/*		DesiredCapabilities cap = null;
		
		@Parameters({"browser"})
		@BeforeClass\\
		public void Magneto(String browser) throws MalformedURLException {
			// Configure different browsers

			if (browser.equals("chrome")) {
				cap = DesiredCapabilities.chrome();
			} else if (browser.equals("firefox")) {
				cap = DesiredCapabilities.firefox();
			} else if (browser.equals("ie")) {
				cap = DesiredCapabilities.internetExplorer();
			}

			driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), cap);

			driver.get("http://demo.opencart.com/");

		}*/
	


	public void changeTo(String title)
	{
		String gethandle = driver.getWindowHandle();
		for(String strhandle :driver.getWindowHandles())
		{
			driver.switchTo().window(strhandle);
			if(driver.getTitle().equals(title))
				break;
		}
	}
		

	@Test(dataProvider = "getData")
	public void demo(Hashtable<String,String> tb) throws InterruptedException {
		//////////////// Login////////////////////////
		demopg.getLoginlink().click();
		demopg.getUsrname().sendKeys(tb.get("uname"));
		demopg.getPass().sendKeys(tb.get("pass"));
		demopg.getGetstart().click();
		demopg.getLogo().click();
		
		///////////////DemoPage////////////////////////
		demopg.getDemoLink().click();
		//////////////Version1Link//////////
		
		
		demopg.getVersion1url().click();
		String actualtitle= driver.getTitle();
		String expectedtitle="Madison Island";
		assertEquals(actualtitle, expectedtitle);
		
		demopg.getVersion1login().click();
		Thread.sleep(2000);
		changeTo("Log into Magento Admin Page");
		demopg.getV1usrname().sendKeys("adminusername");
		demopg.getV1password().sendKeys("adminpassword");
		demopg.getV1log().click();

	}



	private void assertEquals(String actualtitle, String expectedtitle) {
		// TODO Auto-generated method stub
		
	}

	@DataProvider
	public Object[][] getData() throws IOException {
		String filepath = System.getProperty("user.dir") + "/src/com/cg/testdata";
		String filename = "Login.xlsx";
		String sheetname = "Sheet1";
		// TODO Auto-generated method stub
		return ExcelReader.ReadExeclDataToObject(filepath, filename, sheetname);
	}

}



