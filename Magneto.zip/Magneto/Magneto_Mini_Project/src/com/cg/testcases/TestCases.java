package com.cg.testcases;

import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.cg.pageobject.Demo_PageObject;
import com.cg.pageobject.Features_PageObject;
import com.cg.pageobject.Login_Pageobject;
import com.cg.pageobject.MarketPlace_PageObject;
import com.cg.pageobject.PaymentGateway_PageObject;
import com.cg.pageobject.Register_PageObject;
import com.cg.utilities.ExcelReader;

public class TestCases {

	WebDriver driver;
	Register_PageObject regpg;
	PaymentGateway_PageObject page;
	Login_Pageobject loginpg;
	Demo_PageObject demopg;
	MarketPlace_PageObject marketpg;
	Features_PageObject featurepg;
	

	@BeforeMethod
	public void startup() {
		System.setProperty("webdriver.chrome.driver","H:\\Mini_Project\\selenium-master\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.magentomobileshop.com");
		driver.manage().window().maximize();
		page = new PaymentGateway_PageObject(driver);
		loginpg = new Login_Pageobject(driver);
		regpg = new Register_PageObject(driver);
		demopg = new Demo_PageObject(driver);
		marketpg = new MarketPlace_PageObject(driver);
		featurepg = new Features_PageObject(driver);
		
	}

/*		DesiredCapabilities cap = null;
		
		@Parameters({"browser"})
		@BeforeClass\\
		public void Magneto(String browser) throws MalformedURLException {
			// Configure different browsers

			if (browser.equals("chrome")) {
				cap = DesiredCapabilities.chrome();
			} else if (browser.equals("firefox")) {
				cap = DesiredCapabilities.firefox();
			} else if (browser.equals("ie")) {
				cap = DesiredCapabilities.internetExplorer();
			}

			driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), cap);

			driver.get("http://demo.opencart.com/");

		}*/
	



	@Test(dataProvider = "getData")
	public void test1(Hashtable<String,String> tb) throws InterruptedException {
		//////////////// Login////////////////////////
		page.getLoginlink().click();
		page.getUsrname().sendKeys(tb.get("uname"));
		page.getPass().sendKeys(tb.get("pass"));
		page.getGetstart().click();
		page.getLogo().click();

		////////////// AddPaymentGateway////////////////////////
		page.getAddonLink().click();
		page.getAddon().click();
		page.getSearchbox().sendKeys("Credit Card");
		page.getSearch().click();
		page.getAddcart().click();
		page.getAddcartlink().click();
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Thread.sleep(2000);
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		page.getProceed().click();
		

		////////////// Billing Details//////////////////////////
		page.getBillfname().clear();
		page.getBillfname().sendKeys(tb.get("Username"));
		page.getBilllastnm().clear();
		page.getBilllastnm().sendKeys(tb.get("lastname"));
		page.getBillpass().clear();
		page.getBillpass().sendKeys(tb.get("pass"));
		page.getSrcode().click();

		Thread.sleep(2000);
		js.executeScript("window.scrollBy(0,200)");
		page.getTerm().click();
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		page.getPay().click();
		
		Thread.sleep(2000);
		driver.navigate().back();
		
		//page.getMenubar().click();

	}
	
	
	

	private void assertEquals(String actualtitle, String expectedtitle) {
		// TODO Auto-generated method stub
		
	}

	@DataProvider
	public Object[][] getData() throws IOException {
		String filepath = System.getProperty("user.dir") + "/src/com/cg/testdata";
		String filename = "Login.xlsx";
		String sheetname = "Sheet1";
		// TODO Auto-generated method stub
		return ExcelReader.ReadExeclDataToObject(filepath, filename, sheetname);
	}

}
