package com.cg.testcases;

import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.cg.pageobject.MarketPlace_PageObject;

import com.cg.utilities.ExcelReader;

public class MarketPlace_Testcase {
	

	WebDriver driver;

	MarketPlace_PageObject marketpg;

	

	@BeforeMethod
	public void startup() {
		System.setProperty("webdriver.chrome.driver","H:\\Mini_Project\\selenium-master\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.magentomobileshop.com");
		driver.manage().window().maximize();
		marketpg = new MarketPlace_PageObject(driver);
	
		
	}

/*		DesiredCapabilities cap = null;
		
		@Parameters({"browser"})
		@BeforeClass\\
		public void Magneto(String browser) throws MalformedURLException {
			// Configure different browsers

			if (browser.equals("chrome")) {
				cap = DesiredCapabilities.chrome();
			} else if (browser.equals("firefox")) {
				cap = DesiredCapabilities.firefox();
			} else if (browser.equals("ie")) {
				cap = DesiredCapabilities.internetExplorer();
			}

			driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), cap);

			driver.get("http://demo.opencart.com/");

		}*/
	

	
	
	@Test(dataProvider = "getData")
	public void test2(Hashtable<String,String> tb) throws InterruptedException {
		//////////////// Login////////////////////////
		marketpg.getLoginlink().click();
		marketpg.getUsrname().sendKeys(tb.get("uname"));
	    marketpg.getPass().sendKeys(tb.get("pass"));
		marketpg.getGetstart().click();
		marketpg.getLogo().click();
		

		////////////// AddMarketPlace ////////////////////////
		marketpg.getAddonLink().click();
		marketpg.getMarketplace().click();
		marketpg.getSearchbox().sendKeys("Ebay");
		marketpg.getSearch().click();
		marketpg.getAddcart().click();
		marketpg.getAddcartlink().click();
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Thread.sleep(2000);
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		marketpg.getProceed().click();
		

	}

	

	@DataProvider
	public Object[][] getData() throws IOException {
		String filepath = System.getProperty("user.dir") + "/src/com/cg/testdata";
		String filename = "Login.xlsx";
		String sheetname = "Sheet1";
		// TODO Auto-generated method stub
		return ExcelReader.ReadExeclDataToObject(filepath, filename, sheetname);
	}

}



