package com.cg.testcases;

import java.io.IOException;
import java.util.Hashtable;





import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.cg.pageobject.Login_Pageobject;
import com.cg.utilities.ExcelReader;



public class LoginTestcase {

	WebDriver driver;
	Login_Pageobject loginpg;

	

	@BeforeMethod
	public void startup() {
		System.setProperty("webdriver.chrome.driver","H:\\Mini_Project\\selenium-master\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.magentomobileshop.com");
		driver.manage().window().maximize();
		loginpg = new Login_Pageobject(driver);
	
		
	}

/*		DesiredCapabilities cap = null;
		
		@Parameters({"browser"})
		@BeforeClass\\
		public void Magneto(String browser) throws MalformedURLException {
			// Configure different browsers

			if (browser.equals("chrome")) {
				cap = DesiredCapabilities.chrome();
			} else if (browser.equals("firefox")) {
				cap = DesiredCapabilities.firefox();
			} else if (browser.equals("ie")) {
				cap = DesiredCapabilities.internetExplorer();
			}

			driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), cap);

			driver.get("http://demo.opencart.com/");

		}*/
	



	@Test(dataProvider = "getData")
	public void login(Hashtable<String,String> tb) throws InterruptedException {
		//////////////// Login////////////////////////
		loginpg.getLoginlink().click();
		loginpg.getUsrname().sendKeys(tb.get("uname"));
		loginpg.getPass().sendKeys(tb.get("pass"));
		loginpg.getGetstart().click();
	}


	

	@DataProvider
	public Object[][] getData() throws IOException {
		String filepath = System.getProperty("user.dir") + "/src/com/cg/testdata";
		String filename = "Login.xlsx";
		String sheetname = "Sheet1";
		// TODO Auto-generated method stub
		return ExcelReader.ReadExeclDataToObject(filepath, filename, sheetname);
	}

}



