package com.cg.testcases;

import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import com.cg.pageobject.Features_PageObject;
import com.cg.utilities.ExcelReader;

public class Features_Testcase {

	WebDriver driver;
	Features_PageObject featurepg;
	

	@BeforeMethod
	public void startup() {
		System.setProperty("webdriver.chrome.driver","H:\\Mini_Project\\selenium-master\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.magentomobileshop.com");
		driver.manage().window().maximize();
		featurepg = new Features_PageObject(driver);
		
	}

/*		DesiredCapabilities cap = null;
		
		@Parameters({"browser"})
		@BeforeClass\\
		public void Magneto(String browser) throws MalformedURLException {
			// Configure different browsers

			if (browser.equals("chrome")) {
				cap = DesiredCapabilities.chrome();
			} else if (browser.equals("firefox")) {
				cap = DesiredCapabilities.firefox();
			} else if (browser.equals("ie")) {
				cap = DesiredCapabilities.internetExplorer();
			}

			driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), cap);

			driver.get("http://demo.opencart.com/");

		}*/
	



	@Test(dataProvider = "getData")
	public void test3(Hashtable<String,String> tb) throws InterruptedException {
		//////////////// Login////////////////////////
		featurepg.getLoginlink().click();
		featurepg.getUsrname().sendKeys(tb.get("uname"));
		featurepg.getPass().sendKeys(tb.get("pass"));
		featurepg.getGetstart().click();
		Thread.sleep(2000);
		featurepg.getLogo().click();
		
        //////////////Add FeaturesAddon////////////////////////
		featurepg.getAddonLink().click();
		featurepg.getAddon().click();
		featurepg.getSearchbox().sendKeys("Add to Wishlist");
		featurepg.getSearch().click();
		featurepg.getAddcart().click();
		featurepg.getAddcartlink().click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Thread.sleep(2000);
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		featurepg.getProceed().click();
		
        //////////////Billing Details//////////////////////////
		featurepg.getBillfname().clear();
		featurepg.getBillfname().sendKeys(tb.get("Username"));
		featurepg.getBilllastnm().clear();
		featurepg.getBilllastnm().sendKeys(tb.get("lastname"));
		featurepg.getBillpass().clear();
		featurepg.getBillpass().sendKeys(tb.get("pass"));
		featurepg.getSrcode().click();
		
		Thread.sleep(2000);
		js.executeScript("window.scrollBy(0,200)");
		featurepg.getTerm().click();
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		featurepg.getPay().click();
	
		/*

		////////////// Billing Details//////////////////////////
		page.getBillfname().sendKeys("Dhanshree");
		page.getBilllastnm().sendKeys("Tekale");
		page.getBillpass().sendKeys("dhanoo123");
		page.getSrcode().click();

		Thread.sleep(2000);
		js.executeScript("window.scrollBy(0,200)");
		page.getTerm().click();
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		page.getPay().click();
		
		Thread.sleep(2000);
		driver.navigate().back();
		
		//page.getMenubar().click();
*/

		
	}

	@DataProvider
	public Object[][] getData() throws IOException {
		String filepath = System.getProperty("user.dir") + "/src/com/cg/testdata";
		String filename = "Login.xlsx";
		String sheetname = "Sheet1";
		// TODO Auto-generated method stub
		return ExcelReader.ReadExeclDataToObject(filepath, filename, sheetname);
	}

	

}
