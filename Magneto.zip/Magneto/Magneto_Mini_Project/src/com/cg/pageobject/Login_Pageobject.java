package com.cg.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login_Pageobject {

		
		WebDriver driver;
		
		@FindBy(partialLinkText="Log in")
		private WebElement loginlink;
		
		@FindBy(name="username")
		private WebElement usrname;
		
		@FindBy(name="password")
		private WebElement pass;
		
		@FindBy(xpath="//*[@id=\"customer_login\"]/div[1]/div/form/p[6]/input[3]")
		private WebElement getstart;
		
		

		public Login_Pageobject(WebDriver driver) {
			this.driver=driver;
			PageFactory.initElements(driver,this);
		}


		public WebDriver getDriver() {
			return driver;
		}

		public void setDriver(WebDriver driver) {
			this.driver = driver;
		}

		public WebElement getLoginlink() {
			return loginlink;
		}

		public void setLoginlink(WebElement loginlink) {
			this.loginlink = loginlink;
		}

		public WebElement getUsrname() {
			return usrname;
		}

		public void setUsrname(WebElement usrname) {
			this.usrname = usrname;
		}

		public WebElement getPass() {
			return pass;
		}

		public void setPass(WebElement pass) {
			this.pass = pass;
		}

		public WebElement getGetstart() {
			return getstart;
		}

		public void setGetstart(WebElement getstart) {
			this.getstart = getstart;
		}

		
	}


