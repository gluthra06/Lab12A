package com.cg.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Register_PageObject {
	
	WebDriver driver;
	
	@FindBy(linkText="Let's Get Started!!")
	private WebElement letstartLink;
	
	@FindBy(name="first_name")
	private WebElement usrname;
	
	@FindBy(name="email")
	private WebElement mail;
	
	@FindBy(name="password")
	private WebElement passwrd;

	@FindBy(xpath="//*[@id=\"customer_login\"]/div/form/input")
	private WebElement letsgetstart;

	public Register_PageObject(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getLetstartLink() {
		return letstartLink;
	}

	public void setLetstartLink(WebElement letstartLink) {
		this.letstartLink = letstartLink;
	}

	public WebElement getUsrname() {
		return usrname;
	}

	public void setUsrname(WebElement usrname) {
		this.usrname = usrname;
	}

	public WebElement getMail() {
		return mail;
	}

	public void setMail(WebElement mail) {
		this.mail = mail;
	}

	public WebElement getPasswrd() {
		return passwrd;
	}

	public void setPasswrd(WebElement passwrd) {
		this.passwrd = passwrd;
	}

	public WebElement getLetsgetstart() {
		return letsgetstart;
	}

	public void setLetsgetstart(WebElement letsgetstart) {
		this.letsgetstart = letsgetstart;
	}
	
	

}
