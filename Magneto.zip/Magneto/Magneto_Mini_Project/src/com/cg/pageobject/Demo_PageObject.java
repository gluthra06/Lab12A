package com.cg.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Demo_PageObject {
	
	WebDriver driver;

	public Demo_PageObject(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}

	@FindBy(partialLinkText="Log in")
	private WebElement loginlink;
	
	@FindBy(name="username")
	private WebElement usrname;
	
	@FindBy(name="password")
	private WebElement pass;
	
	@FindBy(xpath="//*[@id=\"customer_login\"]/div[1]/div/form/p[6]/input[3]")
	private WebElement getstart;
	
	@FindBy(xpath="//*[@id=\"magento-tap2\"]/div/div/div[1]/div/nav/div/div[1]/a/span[1]/img")
	private WebElement logo;
	
	@FindBy(linkText="Demo")
	private WebElement demoLink;
	
	@FindBy(xpath="//*[@id=\"magento-tap2\"]/section[1]/div/div/div[2]/div[2]/div/div[1]/div[2]/p/a[1]")
	private WebElement version1url;
	
	@FindBy(xpath="//*[@id=\"magento-tap2\"]/section[1]/div/div/div[2]/div[2]/div/div[1]/div[2]/p/a[2]")
	private WebElement version1login;
	
	@FindBy(xpath="//*[@id=\"username\"]")
	private WebElement v1usrname;
	
	@FindBy(xpath="//*[@id=\"login\"]")
	private WebElement v1password;
	
	@FindBy(xpath="//*[@id=\"loginForm\"]/div/div[5]/input")
	private WebElement v1log;
	

	public WebElement getV1usrname() {
		return v1usrname;
	}

	public void setV1usrname(WebElement v1usrname) {
		this.v1usrname = v1usrname;
	}

	public WebElement getV1password() {
		return v1password;
	}

	public void setV1password(WebElement v1password) {
		this.v1password = v1password;
	}

	public WebElement getV1log() {
		return v1log;
	}

	public void setV1log(WebElement v1log) {
		this.v1log = v1log;
	}

	public WebElement getVersion1login() {
		return version1login;
	}

	public void setVersion1login(WebElement version1login) {
		this.version1login = version1login;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getLoginlink() {
		return loginlink;
	}

	public void setLoginlink(WebElement loginlink) {
		this.loginlink = loginlink;
	}

	public WebElement getUsrname() {
		return usrname;
	}

	public void setUsrname(WebElement usrname) {
		this.usrname = usrname;
	}

	public WebElement getPass() {
		return pass;
	}

	public void setPass(WebElement pass) {
		this.pass = pass;
	}

	public WebElement getGetstart() {
		return getstart;
	}

	public void setGetstart(WebElement getstart) {
		this.getstart = getstart;
	}

	public WebElement getLogo() {
		return logo;
	}

	public void setLogo(WebElement logo) {
		this.logo = logo;
	}

	public WebElement getDemoLink() {
		return demoLink;
	}

	public void setDemoLink(WebElement demoLink) {
		this.demoLink = demoLink;
	}

	public WebElement getVersion1url() {
		return version1url;
	}

	public void setVersion1url(WebElement version1url) {
		this.version1url = version1url;
	}

}
