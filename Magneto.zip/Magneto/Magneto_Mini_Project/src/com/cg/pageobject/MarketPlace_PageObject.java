package com.cg.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MarketPlace_PageObject {
	
WebDriver driver;
	
	@FindBy(partialLinkText="Log in")
	private WebElement loginlink;
	
	@FindBy(name="username")
	private WebElement usrname;
	
	@FindBy(name="password")
	private WebElement pass;
	
	@FindBy(xpath="//*[@id=\"customer_login\"]/div[1]/div/form/p[6]/input[3]")
	private WebElement getstart;
	
	@FindBy(xpath="//*[@id=\"magento-tap2\"]/div/div/div[1]/div/nav/div/div[1]/a/span[1]/img")
	private WebElement logo;
	
	@FindBy(linkText="Add Ons")
	private WebElement addonLink;
	
	@FindBy(xpath="//*[@id=\"magento-tap2\"]/section/div/div/div/div[2]/div/a/div[3]/p")
	private WebElement marketplace;
	
	@FindBy(xpath="//*[@id=\"searcvh-empty\"]")
	private WebElement searchbox;
	
	@FindBy(xpath="//*[@id=\"add-ons-div\"]/div[2]/button")
	private WebElement search;

	@FindBy(xpath="//*[@id=\"add-ons-div\"]/ul/li/div/div[2]/p/a")
	private WebElement addcart;
	
	@FindBy(xpath="//*[@id=\"navbar\"]/ul[2]/li[2]/a")
	private WebElement addcartlink;
	
	@FindBy(xpath="//*[@id=\"post-358\"]/div/div/div[4]/div/div/div/a")
	private WebElement proceed;
	
	@FindBy(name="billing_first_name")
	private WebElement billfname;
	
	@FindBy(name="billing_last_name")
	private WebElement billlastnm;

	@FindBy(name="billing_password")
	private WebElement billpass;
	
	@FindBy(name="wps_ext_cst_label")
	private WebElement srcode;
	
	@FindBy(xpath="//*[@id=\"terms\"]")
	private WebElement term;
	
	@FindBy(xpath="//*[@id=\"place_order\"]")
	private WebElement pay;
	

	public MarketPlace_PageObject(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getLoginlink() {
		return loginlink;
	}

	public void setLoginlink(WebElement loginlink) {
		this.loginlink = loginlink;
	}

	public WebElement getUsrname() {
		return usrname;
	}

	public void setUsrname(WebElement usrname) {
		this.usrname = usrname;
	}

	public WebElement getPass() {
		return pass;
	}

	public void setPass(WebElement pass) {
		this.pass = pass;
	}

	public WebElement getGetstart() {
		return getstart;
	}

	public void setGetstart(WebElement getstart) {
		this.getstart = getstart;
	}

	public WebElement getLogo() {
		return logo;
	}

	public void setLogo(WebElement logo) {
		this.logo = logo;
	}

	public WebElement getAddonLink() {
		return addonLink;
	}

	public void setAddonLink(WebElement addonLink) {
		this.addonLink = addonLink;
	}

	public WebElement getMarketplace() {
		return marketplace;
	}

	public void setMarketplace(WebElement marketplace) {
		this.marketplace = marketplace;
	}

	public WebElement getSearchbox() {
		return searchbox;
	}

	public void setSearchbox(WebElement searchbox) {
		this.searchbox = searchbox;
	}

	public WebElement getSearch() {
		return search;
	}

	public void setSearch(WebElement search) {
		this.search = search;
	}

	public WebElement getAddcart() {
		return addcart;
	}

	public void setAddcart(WebElement addcart) {
		this.addcart = addcart;
	}

	public WebElement getAddcartlink() {
		return addcartlink;
	}

	public void setAddcartlink(WebElement addcartlink) {
		this.addcartlink = addcartlink;
	}

	public WebElement getProceed() {
		return proceed;
	}

	public void setProceed(WebElement proceed) {
		this.proceed = proceed;
	}

	public WebElement getBillfname() {
		return billfname;
	}

	public void setBillfname(WebElement billfname) {
		this.billfname = billfname;
	}

	public WebElement getBilllastnm() {
		return billlastnm;
	}

	public void setBilllastnm(WebElement billlastnm) {
		this.billlastnm = billlastnm;
	}

	public WebElement getBillpass() {
		return billpass;
	}

	public void setBillpass(WebElement billpass) {
		this.billpass = billpass;
	}

	public WebElement getSrcode() {
		return srcode;
	}

	public void setSrcode(WebElement srcode) {
		this.srcode = srcode;
	}

	public WebElement getTerm() {
		return term;
	}

	public void setTerm(WebElement term) {
		this.term = term;
	}

	public WebElement getPay() {
		return pay;
	}

	public void setPay(WebElement pay) {
		this.pay = pay;
	}

	
}
