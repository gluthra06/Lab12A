import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login {
	
	public static void main(String args[]) throws InterruptedException
	{
		WebDriver driver;
        //step1. Open the URL on Chrome
		System.setProperty("webdriver.chrome.driver","H:\\Mini_Project\\selenium-master\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.magentomobileshop.com");
		Thread.sleep(2000);
		
		WebElement login = driver.findElement(By.partialLinkText("Log in"));
		login.click();
		
		
		WebElement email = driver.findElement(By.name("username"));
		email.clear();
		email.sendKeys("dhanshree98@gmail.com");
		
		WebElement password = driver.findElement(By.name("password"));
		password.clear();
		password.sendKeys("dhanoo123");
		
		WebElement getstart = driver.findElement(By.xpath("//*[@id=\"customer_login\"]/div[1]/div/form/p[6]/input[3]"));
		getstart.click();
		
		WebElement logo= driver.findElement(By.xpath("//*[@id=\"magento-tap2\"]/div/div/div[1]/div/nav/div/div[1]/a/span[1]/img"));
		logo.click();
		
		driver.findElement(By.linkText("Add Ons")).click();
		
		WebElement addon= driver.findElement(By.xpath("//*[@id=\"magento-tap2\"]/section/div/div/div/div[3]/div/a/div[3]/p"));
		addon.click();
		
		WebElement addcart= driver.findElement(By.xpath("	//*[@id=\"add-ons-div\"]/ul/li[1]/div/div[2]/p/a"));
		addcart.click();
	
	}

}
