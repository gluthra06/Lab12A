import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Register {
	
	public static void main(String args[])
	{
		WebDriver driver;
        //step1. Open the URL on Chrome
		System.setProperty("webdriver.chrome.driver","H:\\Mini_Project\\selenium-master\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.magentomobileshop.com/");
		
		driver.findElement(By.linkText("Let's Get Started!!")).click();
		
		WebElement name = driver.findElement(By.name("first_name"));
		name.clear();
		name.sendKeys("Dhanshree");
		
		WebElement email = driver.findElement(By.name("email"));
		email.clear();
		email.sendKeys("dhanshree98@gmail.com");
		
		WebElement password = driver.findElement(By.name("password"));
		password.clear();
		password.sendKeys("dhanoo123");
		
		WebElement getstart = driver.findElement(By.xpath("//*[@id=\"customer_login\"]/div/form/input"));
		getstart.click();
		
		
		
	
		
	}

}
